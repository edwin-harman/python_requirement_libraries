# -*- coding: utf-8 -*-

from pvfactors.version import __version__
import logging
logging.basicConfig()


class PVFactorsError(Exception):
    pass
