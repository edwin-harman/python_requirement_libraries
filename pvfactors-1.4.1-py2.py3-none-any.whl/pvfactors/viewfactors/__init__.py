"""View factor calculator"""

from pvfactors.viewfactors.calculator import VFCalculator
